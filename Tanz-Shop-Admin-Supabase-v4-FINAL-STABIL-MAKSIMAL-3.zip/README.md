# Tanz Shop — FINAL REVISI

Mempertahankan website, desain, produk, logo, banner, QRIS, dan audio yang sudah ada. Revisi admin/Supabase mencakup:
- urutan produk dan layanan konsisten antara Home dan Panel Admin;
- penyisipan urutan: produk/layanan baru pada nomor tertentu menggeser item setelahnya;
- urutan disimpan kembali ke Supabase tanpa nomor loncat;
- edit mempertahankan ID/row yang sama, bukan membuat duplikat;
- hapus menghapus item terpilih lalu merapikan nomor;
- tombol Tambah Produk dan Tambah Layanan aktif;
- produk baru langsung memiliki tombol Order ke WhatsApp Admin;
- pengaturan tampil/sembunyi produk dari Home melalui aksi admin;
- duplikat produk identik dibersihkan;
- emoji layanan mengikuti daftar asli;
- form produk tetap hanya Layanan, Nama Produk, Harga, dan Urutan;
- form layanan tetap Emoji, Nama Layanan, dan Urutan;
- audio otomatis diputar ketika tombol Masuk ke Store ditekan;
- seluruh aset asli berada di folder assets/.
